package com.huynh.listar_flutter_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
