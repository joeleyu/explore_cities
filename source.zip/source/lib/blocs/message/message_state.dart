part of 'message_bloc.dart';

class MessageState {
  final Widget icon;
  final String value;
  final Duration duration;

  MessageState(
      {required this.icon, required this.value, required this.duration});
}
