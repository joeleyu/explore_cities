enum AuthenticationState {
  loading,
  success,
  fail,
}
