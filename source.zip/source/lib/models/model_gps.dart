class GPSModel {
  final String? name;
  final bool editable;
  final double longitude;
  final double latitude;

  GPSModel({
    required this.longitude,
    required this.latitude,
    this.name,
    this.editable = false,
  });

  factory GPSModel.fromJson(Map<String, dynamic> json) {
    return GPSModel(
      name: json['name'],
      editable: json['editable'],
      longitude: double.tryParse(json['longitude']) ?? 0.0,
      latitude: double.tryParse(json['latitude']) ?? 0.0,
    );
  }
}
